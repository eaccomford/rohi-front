function Footer() {
    return (
        <section className="grid grid-cols-1 px-10 text-gray-800 bg-gray-100 md:px-32 gap-y-10 md:grid-cols-4 py-14">
            <div className="space-y-4 text-xs text-gray-800">
                <h5 className="font-bold">About</h5>
                <p>Why Rohi Church</p>
                <p>WHy we do what we do</p>
                <p>Our Churches</p>
                <p>Love  word messages</p>
                <p>Comminity support</p>
                <p>Come Give</p>
            </div>
            <div className="space-y-4 text-xs text-gray-800">
                <h5 className="font-bold">Contact</h5>
                <p>Why Rohi Church</p>
                <p>WHy we do what we do</p>
                <p>Our Churches</p>
                <p>Love  word messages</p>
                <p>Comminity support</p>
                <p>Come Give</p>
            </div>
            <div className="space-y-4 text-xs text-gray-800">
                <h5 className="font-bold">Social</h5>
                <p>FaceBook</p>
                <p>Twitter</p>
                <p>YouTube</p>
                <p>Love  word messages</p>
                <p>Comminity support</p>
                <p>Come Give</p>
            </div>
            <div className="space-y-4 text-xs text-gray-800">
                <h5 className="font-bold">Pages</h5>
                <p>Why Rohi Church</p>
                <p>WHy we do what we do</p>
                <p>Our Churches</p>
                <p>Love  word messages</p>
                <p>Comminity support</p>
                <p>Come Give</p>
            </div>
        </section>
    )
}

export default Footer
