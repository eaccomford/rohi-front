module.exports = {
    images: {
        domains: ["localhost","https://www.youtube.com"]
    }
}